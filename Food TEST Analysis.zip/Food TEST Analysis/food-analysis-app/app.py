from flask import Flask, render_template, request
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

def predict_nutrition(condition):
    base_info = {
        "Calories": "250 kcal",
        "Sugar": "10g",
        "Protein": "6g",
        "Fat": "12g"
    }
    recommendations = {
        "diabetes": "Avoid high sugar. Recommended: Salad, Grilled Chicken.",
        "anemia": "Eat iron-rich food. Recommended: Spinach, Red Meat, Lentils.",
        "none": "Eat balanced meals. Recommended: Fruits, Veggies, Whole grains."
    }
    result = "\n".join([f"{k}: {v}" for k, v in base_info.items()])
    result += "\n\n" + recommendations.get(condition, recommendations["none"])
    return result

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    image = request.files['foodImage']
    condition = request.form.get('condition', 'none')

    if image:
        image.save(os.path.join(app.config['UPLOAD_FOLDER'], image.filename))

    prediction = predict_nutrition(condition)
    return render_template('index.html', prediction=prediction)

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)
